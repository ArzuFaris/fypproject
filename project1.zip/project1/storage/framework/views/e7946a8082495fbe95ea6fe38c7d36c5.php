

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4>Join a Research Project</h4>
                </div>
                <div class="card-body">
                    <!-- Search Projects Form -->
                    <div class="mb-4">
                        <form action="<?php echo e(route('join.project')); ?>" method="GET" class="row g-3">
                            <div class="col-md-8">
                                <input type="text" name="search" class="form-control" 
                                    placeholder="Search projects by title or ID..." 
                                    value="<?php echo e(request('search')); ?>">
                            </div>
                            <div class="col-auto">
                                <button type="submit" class="btn btn-primary">Search</button>
                                <a href="<?php echo e(route('join.project')); ?>" class="btn btn-secondary">Reset</a>
                            </div>
                        </form>
                    </div>

                    <!-- Available Projects List -->
                    <div class="list-group">
                        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="list-group-item">
                                <div class="d-flex w-100 justify-content-between align-items-center">
                                    <div>
                                        <h5 class="mb-1"><?php echo e($project->project_title); ?></h5>
                                        <p class="mb-1">Project ID: <?php echo e($project->project_id); ?></p>
                                        <small>Project Leader: <?php echo e($project->projectLeader->academician_name); ?></small>
                                        <br>
                                        <small>Status: <?php echo e($project->status); ?></small>
                                    </div>
                                    
                                    <?php if($project->members->contains('academician_id', auth()->user()->academician->academician_id)): ?>
                                        <button class="btn btn-success" disabled>Already Joined</button>
                                    <?php else: ?>
                                        <form action="<?php echo e(route('join.project.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="project_id" value="<?php echo e($project->project_id); ?>">
                                            <input type="hidden" name="academician_id" value="<?php echo e(auth()->user()->academician->academician_id); ?>">
                                            <button type="submit" class="btn btn-primary">Join Project</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center py-3">
                                <p>No projects available to join at this time.</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\fypproject\project1\resources\views/project-members/join.blade.php ENDPATH**/ ?>