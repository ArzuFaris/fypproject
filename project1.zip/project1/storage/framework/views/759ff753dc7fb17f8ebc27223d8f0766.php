
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Milestones</h2>
        <?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'staff' || Auth::user()->role === 'academician'): ?>
            <a href="<?php echo e(route('milestones.create')); ?>" class="btn btn-primary">Add New Milestone</a>
        <?php endif; ?>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('milestones.index')); ?>" method="GET" class="row g-3">
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Search milestones..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary">Search</button>
                    <a href="<?php echo e(route('milestones.index')); ?>" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>
    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Project ID</th>
                            <th>Name</th>
                            <th>Target Completion Date</th>
                            <th>Deliverable</th>
                            <th>Status</th>
                            <th>Remark</th>
                            <th>Last updated</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $milestones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $milestone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($milestone->milestone_id); ?></td>
                            <td><?php echo e($milestone->project_id); ?></td>
                            <td><?php echo e($milestone->name); ?></td>
                            <td><?php echo e($milestone->target_completion_date); ?></td>
                            <td><?php echo e($milestone->deliverable); ?></td>
                            <td><?php echo e($milestone->status); ?></td>
                            <td><?php echo e($milestone->remark); ?></td>
                            <td><?php echo e($milestone->last_updated); ?></td>
                            <td>
                                <div class="btn-group">
                                    <!-- View button - accessible by all -->
                                    <a href="<?php echo e(route('milestones.show', $milestone)); ?>" 
                                       class="btn btn-info btn-sm">View</a>

                                    <!-- Edit button - accessible by admin, staff, and academician -->
                                    <?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'staff'): ?>
                                        <a href="<?php echo e(route('milestones.edit', $milestone)); ?>" 
                                           class="btn btn-warning btn-sm">Edit</a>
                                    <?php endif; ?>

                                    <!-- Delete button - only for admin and staff -->
                                    <?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'staff'): ?>
                                        <form action="<?php echo e(route('milestones.destroy', $milestone)); ?>" 
                                              method="POST" 
                                              class="d-inline"
                                              onsubmit="return confirm('Are you sure?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\fypproject\project1\resources\views/milestones/index.blade.php ENDPATH**/ ?>