

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Project Members</h2>
        <a href="<?php echo e(route('project-members.create')); ?>" class="btn btn-primary">Add New Member</a>
    </div>

    <!-- Search Form -->
    <div class="card mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('project-members.index')); ?>" method="GET" class="row g-3">
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Search members..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary">Search</button>
                    <a href="<?php echo e(route('project-members.index')); ?>" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Members Table -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Member ID</th>
                            <th>Project</th>
                            <th>Academician</th>
                            <th>Role</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $projectmembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($member->project_member_id); ?></td>
                            <td><?php echo e($member->grantProject->project_title); ?></td>
                            <td><?php echo e($member->academician->academician_name); ?></td>
                            <td><?php echo e($member->role); ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="<?php echo e(route('project-members.show', $member)); ?>" class="btn btn-info btn-sm">View</a>
                                    <a href="<?php echo e(route('project-members.edit', $member)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <form action="<?php echo e(route('project-members.destroy', $member)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\fypproject\project1\resources\views/project-members/index.blade.php ENDPATH**/ ?>