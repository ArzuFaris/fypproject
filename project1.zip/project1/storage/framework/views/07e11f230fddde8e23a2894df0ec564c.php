

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Research Grant Projects</h2>
        <?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'staff'): ?>
            <a href="<?php echo e(route('grant-projects.create')); ?>" class="btn btn-primary">Add New Project</a>
        <?php endif; ?>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('grant-projects.index')); ?>" method="GET" class="row g-3">
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Search projects..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-auto">
                    <button type="submit" class="btn btn-primary">Search</button>
                    <a href="<?php echo e(route('grant-projects.index')); ?>" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>
    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Project ID</th>
                            <th>Title</th>
                            <th>Project Leader</th>
                            <th>Grant Amount (RM)</th>
                            <th>Provider</th>
                            <th>Start Date</th>
                            <th>Duration</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $grantprojects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($project->project_id); ?></td>
                            <td><?php echo e($project->title); ?></td>
                            <td><?php echo e($project->projectLeader->academician_name); ?></td>
                            <td><?php echo e(number_format($project->grant_amount, 2)); ?></td>
                            <td><?php echo e($project->grant_provider); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($project->start_date)->format('d/m/Y')); ?></td>
                            <td><?php echo e($project->duration); ?> months</td>
                            <td>
                                <div class="btn-group">
                                    <!-- View button - accessible by all -->
                                    <a href="<?php echo e(route('grant-projects.show', $project)); ?>" 
                                       class="btn btn-info btn-sm">View</a>

                                        <?php if(Auth::user()->role === 'academician' && Auth::user()->academician): ?>
                                            <?php
                                                $isProjectMember = $project->members->contains('academician_id', Auth::user()->academician->academician_id);
                                            ?>
                                            
                                            <?php if(!$isProjectMember): ?>
                                                <form action="<?php echo e(route('grant-projects.join', $project->project_id)); ?>" 
                                                    method="POST" 
                                                    class="d-inline">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-primary btn-sm">Join</button>
                                                </form>
                                            <?php else: ?>
                                                <button disabled class="bg-success" style="color: white;">Member</button>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                    <!-- Edit and Delete buttons - only for admin and staff -->
                                    <?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'staff'): ?>
                                        <a href="<?php echo e(route('grant-projects.edit', $project->project_id)); ?>" 
                                           class="btn btn-warning btn-sm">Edit</a>
                                        <form action="<?php echo e(route('grant-projects.destroy', $project->project_id)); ?>" 
                                              method="POST" 
                                              class="d-inline"
                                              onsubmit="return confirm('Are you sure you want to delete this project?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\fypproject\project1\resources\views/grant-projects/index.blade.php ENDPATH**/ ?>