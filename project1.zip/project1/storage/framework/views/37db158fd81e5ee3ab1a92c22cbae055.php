
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card mb-4">
        <div class="card-header">
            <h2>Research Grant Project Details</h2>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-3"><strong>Project Title:</strong></div>
                <div class="col-md-9"><?php echo e($grantProject->title); ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-3"><strong>Project Leader:</strong></div>
                <div class="col-md-9"><?php echo e($grantProject->projectLeader->academician_name); ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-3"><strong>Grant Amount:</strong></div>
                <div class="col-md-9">RM <?php echo e(number_format($grantProject->grant_amount, 2)); ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-3"><strong>Grant Provider:</strong></div>
                <div class="col-md-9"><?php echo e($grantProject->grant_provider); ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-3"><strong>Start Date:</strong></div>
                <div class="col-md-9"><?php echo e(\Carbon\Carbon::parse($grantProject->start_date)->format('d/m/Y')); ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-3"><strong>Duration:</strong></div>
                <div class="col-md-9"><?php echo e($grantProject->duration); ?> months</div>
            </div>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h3>Project Members</h3>
        </div>
        <div class="card-body">
            <?php if($grantProject->members->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Staff Number</th>
                                <th>Position</th>
                                <th>Department</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $grantProject->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($member->academician->academician_name); ?></td>
                                <td><?php echo e($member->academician->academician_number); ?></td>
                                <td><?php echo e($member->academician->position); ?></td>
                                <td><?php echo e($member->academician->department); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>No project members added yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <h3>Project Milestones</h3>
        </div>
        <div class="card-body">
            <?php if($grantProject->milestones->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Target Date</th>
                                <th>Deliverable</th>
                                <th>Status</th>
                                <th>Last Updated</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $grantProject->milestones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $milestone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($milestone->name); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($milestone->target_completion_date)->format('d/m/Y')); ?></td>
                                <td><?php echo e($milestone->deliverable); ?></td>
                                <td><?php echo e($milestone->status); ?></td>
                                <td><?php echo e($milestone->last_updated ? \Carbon\Carbon::parse($milestone->last_updated)->format('d/m/Y') : '-'); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>No milestones added yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="d-grid gap-2">
        <?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'staff'): ?>
            <a href="<?php echo e(route('grant-projects.edit', $grantProject)); ?>" class="btn btn-warning">Edit Project</a>
        <?php endif; ?>
        <a href="<?php echo e(route('grant-projects.index')); ?>" class="btn btn-secondary">Back to List</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\fypproject\project1\resources\views/grant-projects/show.blade.php ENDPATH**/ ?>