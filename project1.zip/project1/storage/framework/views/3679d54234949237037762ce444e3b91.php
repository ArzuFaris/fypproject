
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h2>Academician Details</h2>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-3"><strong>Name:</strong></div>
                <div class="col-md-9"><?php echo e($academician->academician_name); ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-3"><strong>Staff Number:</strong></div>
                <div class="col-md-9"><?php echo e($academician->academician_number); ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-3"><strong>Email:</strong></div>
                <div class="col-md-9"><?php echo e($academician->email); ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-3"><strong>College:</strong></div>
                <div class="col-md-9"><?php echo e($academician->college); ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-3"><strong>Department:</strong></div>
                <div class="col-md-9"><?php echo e($academician->department); ?></div>
            </div>
            <div class="row mb-3">
                <div class="col-md-3"><strong>Position:</strong></div>
                <div class="col-md-9"><?php echo e($academician->position); ?></div>
            </div>

            <div class="d-grid gap-2">
                <a href="<?php echo e(route('academicians.edit', $academician)); ?>" class="btn btn-warning">Edit</a>
                <a href="<?php echo e(route('academicians.index')); ?>" class="btn btn-secondary">Back to List</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\fypproject\project1\resources\views/academicians/show.blade.php ENDPATH**/ ?>