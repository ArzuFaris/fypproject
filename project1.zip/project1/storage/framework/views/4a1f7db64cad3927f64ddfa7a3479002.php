
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">
            <h2>Milestone Details</h2>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-3"><strong>ID:</strong></div>
                <div class="col-md-9"><?php echo e($milestone->milestone_id); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3"><strong>Project ID:</strong></div>
                <div class="col-md-9"><?php echo e($milestone->project_id); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3"><strong>Name:</strong></div>
                <div class="col-md-9"><?php echo e($milestone->name); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3"><strong>Target Completion Date:</strong></div>
                <div class="col-md-9"><?php echo e($milestone->target_completion_date); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3"><strong>Deliverable:</strong></div>
                <div class="col-md-9"><?php echo e($milestone->deliverable); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3"><strong>Status:</strong></div>
                <div class="col-md-9"><?php echo e($milestone->status); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3"><strong>Remark:</strong></div>
                <div class="col-md-9"><?php echo e($milestone->remark); ?></div>
            </div>

            <div class="row mb-3">
                <div class="col-md-3"><strong>Last Updated:</strong></div>
                <div class="col-md-9"><?php echo e($milestone->last_updated); ?></div>
            </div>

            <div class="d-grid gap-2">
                <a href="<?php echo e(route('milestones.edit', $milestone->milestone_id)); ?>" class="btn btn-warning">Edit</a>
                <form action="<?php echo e(route('milestones.destroy', $milestone->milestone_id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger w-100" onclick="return confirm('Are you sure?')">Delete</button>
                </form>
                <a href="<?php echo e(route('milestones.index')); ?>" class="btn btn-secondary">Back to List</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\fypproject\project1\resources\views/milestones/show.blade.php ENDPATH**/ ?>